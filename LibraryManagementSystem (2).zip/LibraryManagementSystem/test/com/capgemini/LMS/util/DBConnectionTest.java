package com.capgemini.LMS.util;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.Test;

import com.capgemini.LMS.exception.LibraryException;



public class DBConnectionTest {

	@Test
	public void test() throws LibraryException, SQLException{
		assertNotNull(DBConnection.getConnection());
	}

}
