package com.capgemini.LMS.bean;

import java.time.LocalDate;

public class BooksRegistration {

	private String registration_id;
	private BooksInventory book_id;
	private Users user_id;
	private LocalDate registrationdate;
	public BooksRegistration() {
		super();
	}
	public BooksRegistration(String registration_id, BooksInventory book_id, Users user_id,
			LocalDate registrationdate) {
		super();
		this.registration_id = registration_id;
		this.book_id = book_id;
		this.user_id = user_id;
		this.registrationdate = registrationdate;
	}
	public String getRegistration_id() {
		return registration_id;
	}
	public void setRegistration_id(String registration_id) {
		this.registration_id = registration_id;
	}
	public BooksInventory getBook_id() {
		return book_id;
	}
	public void setBook_id(BooksInventory book_id) {
		this.book_id = book_id;
	}
	public Users getUser_id() {
		return user_id;
	}
	public void setUser_id(Users user_id) {
		this.user_id = user_id;
	}
	public LocalDate getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(LocalDate registrationdate) {
		this.registrationdate = registrationdate;
	}
	@Override
	public String toString() {
		return "BooksRegistration [registration_id=" + registration_id + ", book_id=" + book_id + ", user_id=" + user_id
				+ ", registrationdate=" + registrationdate + "]";
	}
	
	
}
