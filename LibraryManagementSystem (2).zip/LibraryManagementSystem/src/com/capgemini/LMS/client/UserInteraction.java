package com.capgemini.LMS.client;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.bean.Users;

public class UserInteraction {
	
	 Scanner scanner = new Scanner(System.in);
	 BooksInventory book = new BooksInventory();
	 BooksRegistration register = new BooksRegistration();
	 BooksTransaction trans = new BooksTransaction();
	 Users user = new Users();
	
	
	public void printBooks(List<BooksInventory> books)
	{
		System.out.println("BookID\tBookName\t"
				+ "Author1\t\tAuthor2\t  Publisher\t  YearofPublisher");
		System.out.println("-----------------------------------------------------------------");

		for(BooksInventory book:books)
		{
			System.out.println(book.getBook_id()+"\t   "+book.getBook_name()+"\t\t    "+
					book.getAuthor1()+"\t   "+book.getAuthor2()+"\t   "+book.getPublisher()+"\t   "+
					book.getYearofpub());
		}
	}
	
	
	
	public void printRegistrationRequest(List<BooksRegistration> registers)
	{
		System.out.println("RegistrationID\t  RegistrationDate\t");
		System.out.println("-----------------------------------------------------------------");

		for(BooksRegistration register:registers)
		{
			System.out.println(register.getRegistration_id()+"\t   "+register.getRegistrationdate());
		}
	}
	
	
	public void printTransactions(List<BooksTransaction> transactions)
	{
		System.out.println("TransactionID\tIssueDate\t"
				+ "ReturnDate\tFine");
		System.out.println("-----------------------------------------------------------------");

		for(BooksTransaction transaction:transactions)
		{
			System.out.println(transaction.getTransaction_id()+"\t   "+transaction.getIssue_date()+"\t   "+transaction.getReturn_date()+"\t   "+transaction.getFine());
		}
	}
	
	public BooksInventory findallbooks(List<BooksInventory> books)
	{

		
		System.out.println("Enter your Book_Id");
		String Book_Id;
		Book_Id=scanner.next();

		for(BooksInventory book : books)
		{
			
			if(Book_Id.equals(book.getBook_id()))
			{
				return book;
			}

		}

		return null;
		}
	
	
	public BooksInventory getBook(String book_id, List<BooksInventory> books)
	{
		for(BooksInventory book:books)
		{
			if(book.getBook_id().equals("book_id"));
				return book;
		}
		System.out.println("Enter valid Book ID!");
		return null;
	}
	
	public Users getUser(String userName, List<Users> users)
	{
		for(Users user:users)
		{
			if(user.getUser_name().equals(userName));
				return user;
		}
		System.out.println("Enter valid User ID!");
		return null;
	}
	
	public BooksRegistration getRegister(String user_id, List<BooksRegistration> registers)
	{
		for(BooksRegistration register:registers)
		{
			if(register.getRegistration_id().equals("user_id"));
				return register;
		}
		System.out.println("Enter valid Registration ID!");
		return null;
	}
	
	
	public BooksTransaction getTransaction(String transact_id, List<BooksTransaction> transactions)
	{
		for(BooksTransaction transaction:transactions)
		{
			if(transaction.getRegistration_id().equals("transact_id"));
				return transaction;
		}
		System.out.println("Enter valid Transaction ID!");
		return null;
	}
	
	public BooksRegistration register(BooksInventory bookId , Users userId)
	{	
		BooksInventory bookInvet =new BooksInventory();
		System.out.println("You can register by filling details");
		System.out.println("Enter your registration_Id");
		String reg_id = scanner.next();
		register.setRegistration_id(reg_id);
		register.setBook_id(bookId);
		register.setUser_id(userId);
		LocalDate reg_date = LocalDate.now();
		System.out.println("Your registration date"+reg_date);
		register.setRegistrationdate(reg_date);
		
		
		return register;
	}
	
	
	
	public BooksInventory getDetailsofBook()
	{
		System.out.println("Enter Book Id");
		String book_id = scanner.nextLine();
		book.setBook_id(book_id);
		System.out.println("Enter Book Name");
		String book_name = scanner.nextLine();
		book.setBook_name(book_name);
		System.out.println("Enter Book Author 1");
		String author1 = scanner.nextLine();
		book.setAuthor1(author1);
		System.out.println("Enter Book Author 2");
		String author2 = scanner.nextLine();
		book.setAuthor2(author2);
		System.out.println("Enter Book Publisher");
		String publisher = scanner.nextLine();
		book.setPublisher(publisher);
		System.out.println("Enter Book Year of Publishing");
		String yearofpub = scanner.nextLine();
		book.setYearofpub(yearofpub);
		
		return book;
		
	}
	
	public BooksTransaction transaction(BooksRegistration bookreg)
	{	
		BooksRegistration registerissue =new BooksRegistration();
		System.out.println("You can do transaction by entering transaction_id");
		System.out.println("Enter your Transaction_Id");
		String trans_id = scanner.next();
		trans.setTransaction_id(trans_id);
		trans.setRegistration_id(bookreg);
		LocalDate issue_date = LocalDate.now();
		System.out.println("Your issue date is"+issue_date);
		trans.setIssue_date(issue_date);
		
		
		return trans;
	}
	
	
	
		
		
	}
	


