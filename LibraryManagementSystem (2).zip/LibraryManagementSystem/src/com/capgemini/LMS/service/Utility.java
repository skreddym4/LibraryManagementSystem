package com.capgemini.LMS.service;

public class Utility {

	
	public static boolean isvaliduser(String userName)
	{
		 if(userName.matches("[a-zA-Z]+"))
		 {
			 
				 return true;
			 
		 }
		 return false;
	}
}

