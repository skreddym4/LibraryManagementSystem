package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.DAO.IRegistrationDao;
import com.capgemini.LMS.DAO.RegistrationDaoImpl;
import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.exception.LibraryException;

public class RegistrationServiceImpl implements IRegistrationService{

	
	IRegistrationDao regdao = new RegistrationDaoImpl();
	@Override
	public List<BooksRegistration> getRegistration(Users user, BooksInventory books) throws LibraryException {
		// TODO Auto-generated method stub
		return regdao.getRegistration(user, books);
	}

	@Override
	public void doRegistration(BooksInventory books, Users user, BooksRegistration register) throws LibraryException {
		regdao.doRegistration(books, user, register);
		
	}

}
