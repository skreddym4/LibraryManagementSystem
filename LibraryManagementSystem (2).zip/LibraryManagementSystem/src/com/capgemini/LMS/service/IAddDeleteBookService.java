package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.exception.LibraryException;



public interface IAddDeleteBookService {
	
		public void addBook(BooksInventory booksinventory)throws LibraryException;
		public List<BooksInventory> getallbooks()throws LibraryException;
		public void deleteBook(String bookId)throws LibraryException;

}
