package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.util.DBConnection;


public class AddDeleteBookDaoImpl implements IAddDeleteBookDao {
	
	
	

	@Override
	public void addBook(BooksInventory booksinventory) {
		
		
				
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			PreparedStatement st=connection.prepareStatement(QueryMapper.BOOK_INSERT);
			st.setString(1, booksinventory.getBook_id());
			st.setString(2, booksinventory.getBook_name());
			st.setString(3, booksinventory.getAuthor1());
			st.setString(4, booksinventory.getAuthor2());
			st.setString(5, booksinventory.getPublisher());
			st.setString(6, booksinventory.getYearofpub());
			
			
			int row=st.executeUpdate();

			if(row>0)
				System.out.println("Book has been added to the library!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			
			
			
			
	}

	@Override
	public List<BooksInventory> getallbooks() {
		
		List<BooksInventory> lst = new ArrayList<>();
		
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement1=connection.createStatement();)
		{
			PreparedStatement statement2=connection.prepareStatement(QueryMapper.DISPLAY_BOOKS);
			ResultSet rs= statement2.executeQuery();
			
			
			while(rs.next())
			{
				BooksInventory addbook = new BooksInventory();
				addbook.setBook_id(rs.getString(1));
				addbook.setBook_name(rs.getString(2));
				addbook.setAuthor1(rs.getString(3));
				addbook.setAuthor2(rs.getString(4));
				addbook.setPublisher(rs.getString(5));
				addbook.setYearofpub(rs.getString(6));
				lst.add(addbook);
			}
			
		
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
		return lst;
	
	
}
	
	
	public void deleteBook(String bookId) {
		
		
		
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement1=connection.createStatement();){
			
			
			PreparedStatement pst1=connection.prepareStatement(QueryMapper.DELETE_BOOK_FOREIGN_KEY_CHECK1);
			ResultSet rs1 =pst1.executeQuery();
			PreparedStatement pst=connection.prepareStatement(QueryMapper.DELETE_BOOK);
			pst.setString(1, bookId);
			int row = pst.executeUpdate();
			
					if(row<0)
					{
						System.out.println("Book has not been deleted");
					}
					else
					{
						System.out.println("Book has  been deleted");
					}
			 
			 
			 PreparedStatement pst2=connection.prepareStatement(QueryMapper.DELETE_BOOK_FOREIGN_KEY_CHECK2);
				ResultSet rs2 =pst1.executeQuery();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
}
