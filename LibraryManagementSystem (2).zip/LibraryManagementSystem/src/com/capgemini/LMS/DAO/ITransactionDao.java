package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.exception.LibraryException;

public interface ITransactionDao {
	
	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration regid)throws LibraryException;
	public List<BooksTransaction> getAllTransaction(BooksRegistration regid)throws LibraryException;	
}
