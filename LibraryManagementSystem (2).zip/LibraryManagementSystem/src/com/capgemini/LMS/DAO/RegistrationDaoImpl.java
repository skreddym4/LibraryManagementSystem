package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.LMS.bean.BooksInventory;
import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.Users;
import com.capgemini.LMS.util.DBConnection;

public class RegistrationDaoImpl implements IRegistrationDao{

	@Override
	public List<BooksRegistration> getRegistration(Users user , BooksInventory books) {
		List<BooksRegistration> registers =new ArrayList<>();
		
		
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			BooksInventory book = new BooksInventory();
			Users userid = new Users();
			PreparedStatement statement1=connection.prepareStatement(QueryMapper.CHECK_USER_ID);
			PreparedStatement statement2=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
			PreparedStatement statement3=connection.prepareStatement(QueryMapper.DISPLAY_BOOKS);
			statement1.setString(1, user.getUser_id());
			ResultSet rs= statement1.executeQuery();
			ResultSet rs1= statement2.executeQuery();
			ResultSet rs2= statement3.executeQuery();
			
			
			while(rs2.next())
			{
				
				book.setBook_id(rs2.getString(1));
				
			}
			
			while(rs1.next())
			{
				userid.setUser_id(rs1.getString(1));
			}
			
			while(rs.next())
			{
				BooksRegistration reg =new BooksRegistration();
				reg.setRegistration_id(rs.getString(1));
				reg.setBook_id(book);
				reg.setUser_id(userid);
				reg.setRegistrationdate(rs.getDate(4).toLocalDate());
				registers.add(reg);	
			
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return registers;
	}

	@Override
	public void doRegistration(BooksInventory books, Users user, BooksRegistration register) {
		
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			PreparedStatement statement1=connection.prepareStatement(QueryMapper.INSERT_BOOK);
			
			statement1.setString(1, register.getRegistration_id());
			statement1.setString(2, register.getBook_id().getBook_id());
			statement1.setString(3, register.getUser_id().getUser_id());
			statement1.setDate(4, java.sql.Date.valueOf(register.getRegistrationdate()));
			
			int row=statement1.executeUpdate();
			
			if(row>0)
				System.out.println("Your book has been registerd and forwarded to librarian!");
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
