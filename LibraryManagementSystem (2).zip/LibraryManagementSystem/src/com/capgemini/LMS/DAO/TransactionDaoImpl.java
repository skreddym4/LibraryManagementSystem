package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.LMS.bean.BooksRegistration;
import com.capgemini.LMS.bean.BooksTransaction;
import com.capgemini.LMS.util.DBConnection;

public class TransactionDaoImpl implements ITransactionDao{

	@Override
	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration regid) {
		
				
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			PreparedStatement st=connection.prepareStatement(QueryMapper.ADD_BOOK_TRANSACTION);
			st.setString(1, bookstransaction.getTransaction_id());
			st.setString(2, regid.getRegistration_id());
			st.setDate(3, java.sql.Date.valueOf(bookstransaction.getIssue_date()));
			int row=st.executeUpdate();
			if(row>0)
				System.out.println("The Book has been issued to the student");			
		} catch (SQLException e) {
			e.printStackTrace();
		}			
	}
	
	@Override
	public List<BooksTransaction> getAllTransaction(BooksRegistration regid) {
		
		List<BooksTransaction> transaction =new ArrayList<>();
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			BooksRegistration reg = new BooksRegistration();
			PreparedStatement statement1=connection.prepareStatement(QueryMapper.DISPLAY_BOOK_TRANSACTION);
			PreparedStatement statement2=connection.prepareStatement(QueryMapper.DISPLAY_BOOK_REGISTRATION);
			
			ResultSet rs= statement1.executeQuery();
			ResultSet rs1= statement2.executeQuery();
			
			
			while(rs1.next())
			{
				
				reg.setRegistration_id(rs1.getString(1));
				
			}
			
			
			while(rs.next())
			{
				BooksTransaction trans =new BooksTransaction();
				trans.setTransaction_id(rs.getString(1));
				trans.setRegistration_id(regid);
				trans.setIssue_date(rs.getDate(3).toLocalDate());
				trans.setReturn_date(rs.getDate(4).toLocalDate());
				trans.setFine(rs.getInt(5));
				transaction.add(trans);	
			
			}
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return transaction;
	}

}
